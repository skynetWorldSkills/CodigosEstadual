/*----------------------------------------------------------------------------*/
/* Copyright (c) 2019 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot.subsystems;

import com.kauailabs.navx.frc.AHRS;
import com.studica.frc.TitanQuad;
import com.studica.frc.TitanQuadEncoder;

import edu.wpi.first.wpilibj.SPI;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.Constants;

public class Drive extends SubsystemBase {
  
  private TitanQuad motorLeftUp;
  private TitanQuad motorLeftDown;
  private TitanQuad motorRightUp;
  private TitanQuad motorRightDown;

  private TitanQuadEncoder encoderLeftUp;
  private TitanQuadEncoder encoderLeftDown;
  private TitanQuadEncoder encoderRightUp;
  private TitanQuadEncoder encoderRightDown;

  private AHRS gyro;
  
  public Drive() {

    motorLeftUp = new TitanQuad(Constants.TITAN_ID, Constants.MOTOR_LEFT_SUP);
    motorLeftDown = new TitanQuad(Constants.TITAN_ID, Constants.MOTOR_LEFT_INF);
    motorRightUp = new TitanQuad(Constants.TITAN_ID, Constants.MOTOR_RIGHT_SUP);
    motorRightDown = new TitanQuad(Constants.TITAN_ID, Constants.MOTOR_RIGHT_INF);

    encoderLeftUp = new TitanQuadEncoder(motorLeftUp, Constants.MOTOR_LEFT_SUP, Constants.DIST_PER_TICK);
    encoderLeftDown = new TitanQuadEncoder(motorLeftDown, Constants.MOTOR_LEFT_INF, Constants.DIST_PER_TICK);
    encoderRightUp = new TitanQuadEncoder(motorRightUp, Constants.MOTOR_RIGHT_SUP, Constants.DIST_PER_TICK);
    encoderRightDown = new TitanQuadEncoder(motorRightUp, Constants.MOTOR_RIGHT_INF, Constants.DIST_PER_TICK);

    gyro = new AHRS(SPI.Port.kMXP);
  }

  //Para os motores
  public void xbotDrive(double x, double y, double z){
    double denomantor = Math.max(Math.abs(x) + Math.abs(y) + Math.abs(z), 1.0);
    motorLeftUp.set(y + (x) + z / denomantor);
    motorLeftDown.set(y - (x) + z / denomantor);
    motorRightUp.set(y - (x) - z / denomantor);
    motorRightDown.set(y + (x) - z / denomantor);
  }

  public void stopMotors(){
    motorLeftUp.set(0.0);
    motorLeftDown.set(0.0);
    motorRightUp.set(0.0);
    motorRightDown.set(0.0);
  }

  // Para o giroscópio
  public double getAngle(){
    return gyro.getAngle();
  }

  public double getYaw(){
    return gyro.getYaw();
  }

  public void resetGyro(){
    gyro.reset();
  }

  //Para os encoders
  public void resetEncoders(){
    encoderLeftDown.reset();
    encoderLeftUp.reset();
    encoderRightDown.reset();
    encoderRightUp.reset();
  }

  public double getDistanceAvarageForward(){
    return ((Math.abs(encoderLeftUp.getEncoderDistance()) + Math.abs(encoderRightUp.getEncoderDistance())) / 2);
  }

  @Override
  public void periodic() {
    SmartDashboard.putNumber("Angle", getAngle());
    SmartDashboard.putNumber("Yaw", getYaw());
    SmartDashboard.putNumber("GetAvarageForward", getDistanceAvarageForward());
  }
}
